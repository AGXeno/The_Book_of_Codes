class HashMap:
    def __init__(self):
        self._size = 0  # the number of elements currently being held by hashmap
        self._capacity = 7  # capacity gives the number of elements it can hold.
        self.hash_map = {}

    def hash_function(self, key):
        """
        generate hash code for (r,c) tuples
        ord = return unicode of specified   character
        :param text:
        :return: hash code
        """
        return sum(ord(character) for character in key)

    def get(self, key):
        """
        Return the value for key if key is in the dictionary. If key is not in the
        dictionary, raise a KeyError.
        :param key:
        :return:
        """
        #print(key)
        key_found = False
        for bucket in self.hash_map:
            # print(f"{bucket}, {key}")
            if bucket == key:
                key_found = True
                return self.hash_map.get(bucket)

        if key_found == False:
            raise KeyError

        """
        # get index of key using hash function
        hashed_key = hash(key) % self._capacity
        # get bucket corresponding to index
        bucket = self.hash_map[hashed_key]
        record_val = ""
        found_key = False
        for index, record in enumerate(bucket):
            record_key, record_val = record

            # check if bucket has same key as the key being searched
            if record_key == key:
                found_key = True
                break
        # if bucket has same key as key being searched,
        # return the value that's been found
        if found_key:
            return record_val
        else:
            return None
        """

    def set(self, key, value):
        """
        add the (key,value) pair to the hashMap. After adding, if the load-
        factor
        >= 80%, rehash the map into a map double its current capacity.
        :param key:
        :param value:
        :return:
        """
        self.hash_map[key] = value

        self._size += 1

        # size / capacity
        load_factor = (self._size / self._capacity) * 100
        if load_factor >= 80.0:
            self._capacity = (self._capacity * 2) - 1

    def remove(self, key):
        """
         Remove the key and its associated value from the map. If the key
        does not exist, nothing happens. Do not rehash the table after deleting keys.
        :param key:
        :return:
        """

        key_found = False
        for bucket in self.hash_map:
            if bucket == key:
                print(f"found {key}")
                key_found = True
                break

        if key_found:
            self.hash_map.pop(key)

        self._size -= 1

    def clear(self):
        """
        empty hashmap
        :return:
        """
        self.hash_map.clear()
        self._size = 0
        self._capacity = 7

    def capacity(self):
        """
        Return the current capacity--number of buckets--in the map.
        :return:
        """
        return self._capacity

    def size(self):
        """
        return size of hashmap
        :return:
        """
        return self._size

    def keys(self):
        """
        return a list of keys
        :return:
        """
        lyst = []  # how to add keys??
        for i in self.hash_map:
            lyst.append(i)

        return lyst
