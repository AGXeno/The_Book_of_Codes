"""
Carrie Kwong
Project 2 - Human Pyramids
Class: CS 1410-602
File description: This code calculates the weight of each person forming
a human pyramid. It also displays elapsed time and how many cache hits that
happened.

Declaration: "I declare that the following source code was written solely by me.
I understand that copying any source code, in whole or in part,
constitutes cheating, and that I will receive a zero on this project
if I am found in violation of this policy."

#When base case = 0, return value
#work backwards

"""
import sys
from time import perf_counter

weightCount = 0
cacheCount = 0
cache = {}


def weight_on(row, column):
    """
    Calculates the weight on the back of a person at a given row and collumn of the human pyramid
    :param row: row if the person (int)
    :param column: column of the person (int)
    :return: formatted weight (string)
    """
    global weightCount
    global cacheCount
    # Count to keep track of how many times weight_on() is being used
    weightCount += 1

    # checks to see if the case is in the cache
    # return the case and its value if it exists
    if (row, column) in cache:
        cacheCount += 1
        return cache[(row, column)]

    # base case, when the function can't do recursive anymore
    elif row == 0 and column == 0:
        returnvalue = 0

    # for the left hand side of the pyramid
    elif column == 0:
        returnvalue = (weight_on(row - 1, column) / 2 + 100)

    # for the right hand side of the pyramid
    elif row == column:
        returnvalue = weight_on((row - 1), (column - 1)) / 2 + 100

    # weight_on is the case above the middleman. There's two weight_ons to represent the two cases above the middleman
    # divide by two because of needing to add half the weights the above cases are holding up
    # add 200 in order to add half the weight from each case above the middle man
    else:
        returnvalue = weight_on((row - 1), (column - 1)) / 2 + weight_on(row - 1, column) / 2 + 200

    # Add the case and the weight the case it is holding into the cache
    cache[(row, column)] = returnvalue
    format_value = "{:.2f}".format(returnvalue)
    return format_value


def main():
    file2 = open('part2.txt', 'w')

    start = perf_counter()
    file2.write(f"Program = {sys.argv[0]}\n")

    rowInput = int(sys.argv[1])
    # create for loop for row
    for row in range(rowInput):
        # create for loop within row, for loop for column
        for column in range(row + 1):
            # insert command input for row and column into weight_on ()
            file2.write(f"{weight_on(row, column)} ")
        file2.write("\n")
    file2.write("\n")

    # continue recursive function until there's not more to calculate
    # Print time, # of function calls and # of cache hits
    file2.write(f"Elasped time: {perf_counter() - start} seconds\n")
    file2.write(f"Number of function calls:  {weightCount}\n")
    file2.write(f"Number of cache hits: {cacheCount}\n")


if __name__ == "__main__":
    main()
